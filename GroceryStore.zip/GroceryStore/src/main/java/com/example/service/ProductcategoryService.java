package com.example.service;

import java.util.List;

import com.example.DTO.ProductcategoryDTO;
import com.example.entities.Productcategory;

public interface ProductcategoryService {

    public Productcategory saveProductcategory(Productcategory productcategory);
	
	public List<Productcategory> getAllProductcategory();
	public ProductcategoryDTO createProductcategory(Productcategory productcategory);
	public List<ProductcategoryDTO> getAllProductcategoryInfo();
	public ProductcategoryDTO getProductcategoryById(int id);
	public String deleteProductcategoryById(int id);
	public ProductcategoryDTO updateProductcategory(int id, Productcategory productcategory);
}
