package com.example.service;

import java.util.List;

import com.example.DTO.UserDTO;
import com.example.entities.User;

public interface UserService {

	
	public User saveUser(User user);
	
	public List<User> getAllUser();

	public UserDTO createUser(User user);
	public List<UserDTO> getAllUserInfo();
	public UserDTO getUserById(int id);
	public String deleteUserById(int id);
	public UserDTO updateUser(int id, User user);

}
