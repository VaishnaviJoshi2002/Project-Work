package com.example.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.DTO.OrdersDTO;
import com.example.entities.Orders;
import com.example.repository.OrdersRepository;
import com.example.utility.OrdersConverter;

@Service
public class OrdersServiceImpl  implements OrdersService{

	@Autowired
	private OrdersRepository ordersRepository;
	
	@Autowired
    OrdersConverter ordersconverter;
	
	
	public Orders saveOrders(Orders orders) {
		// TODO Auto-generated method stub
		return ordersRepository.save(orders);
	}

	
	public List<Orders> getAllOrders(){
		
		return ordersRepository.findAll();
		
	}
	
	@Override
	public OrdersDTO createOrders(Orders orders) {
		// TODO Auto-generated method stub
	  Orders o= ordersRepository.save(orders);
	  return ordersconverter.convertToOrdersDTO(o);
	}

	@Override
	public List<OrdersDTO> getAllOrdersInfo() {
		// TODO Auto-generated method stub
		List<Orders> orders= ordersRepository.findAll();
		List<OrdersDTO> dtos=new ArrayList<>();
		for(Orders o:orders)
		{
			dtos.add(ordersconverter.convertToOrdersDTO(o));
		}
		
		
		return dtos;
	}

	@Override
	public OrdersDTO getOrdersById(int id) {
		// TODO Auto-generated method stub
		Orders o1 = ordersRepository.findById(id).get();
		return ordersconverter.convertToOrdersDTO(o1);
	}

	@Override
	public String deleteOrdersById(int id) {
		// TODO Auto-generated method stub
				ordersRepository.deleteById(id);
				return "Orders deleted.";
	}

	@Override
	public OrdersDTO updateOrders(int id, Orders orders) {
		// TODO Auto-generated method stub
		
		Orders a1 = ordersRepository.findById(id).get();
		a1.setOAmount(orders.getOAmount());
		a1.setODate(orders.getODate());
		
		
		
		Orders o=ordersRepository.save(a1);
		return ordersconverter.convertToOrdersDTO(o);
	}
}