package com.example.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.DTO.ProductcategoryDTO;
import com.example.entities.Productcategory;
import com.example.repository.ProductcategoryRepository;
import com.example.utility.ProductcategoryConverter;


@Service
public class ProductcategoryServiceImpl implements ProductcategoryService {

	@Autowired
	private ProductcategoryRepository productcategoryRepository;
	
	@Autowired
	ProductcategoryConverter productcategoryconverter;
	
	public Productcategory saveProductcategory(Productcategory productcategory) {
		// TODO Auto-generated method stub
		return productcategoryRepository.save(productcategory);
	}

	
	public List<Productcategory> getAllProductcategory(){
		
		return productcategoryRepository.findAll();
		
	}
	
	@Override
	public ProductcategoryDTO createProductcategory(Productcategory productcategory) {
		// TODO Auto-generated method stub
		Productcategory p= productcategoryRepository.save(productcategory);
	  return productcategoryconverter.convertToProductcategoryDTO(p);
	}

	@Override
	public List<ProductcategoryDTO> getAllProductcategoryInfo() {
		// TODO Auto-generated method stub
		List<Productcategory> productcategory= productcategoryRepository.findAll();
		List<ProductcategoryDTO> dtos=new ArrayList<>();
		for(Productcategory p:productcategory)
		{
			dtos.add(productcategoryconverter.convertToProductcategoryDTO(p));
		}
		
		
		return dtos;
	}

	@Override
	public ProductcategoryDTO getProductcategoryById(int id) {
		// TODO Auto-generated method stub
		Productcategory p1 = productcategoryRepository.findById(id).get();
		return productcategoryconverter.convertToProductcategoryDTO(p1);
	}

	@Override
	public String deleteProductcategoryById(int id) {
		// TODO Auto-generated method stub
		productcategoryRepository.deleteById(id);
				return "Productcategory deleted.";
	}

	@Override
	public ProductcategoryDTO updateProductcategory(int id, Productcategory productcategory) {
		// TODO Auto-generated method stub
		
		Productcategory a1 = productcategoryRepository.findById(id).get();
		a1.setCId(productcategory.getCId());
		a1.setCName(productcategory.getCName());
		
		Productcategory p=productcategoryRepository.save(a1);
		return productcategoryconverter.convertToProductcategoryDTO(p);
	}
}
