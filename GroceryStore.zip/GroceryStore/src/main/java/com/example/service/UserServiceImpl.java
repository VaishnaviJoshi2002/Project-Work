package com.example.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.DTO.UserDTO;
import com.example.entities.User;
import com.example.repository.UserRepository;
import com.example.utility.UserConverter;



@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;
	
	 @Autowired
	    UserConverter userconverter;
	
	public User saveUser(User user) {
		// TODO Auto-generated method stub
		return userRepository.save(user);
	}

	
	public List<User> getAllUser(){
		
		return userRepository.findAll();
		
	}
	
	@Override
	public UserDTO createUser(User user) {
		// TODO Auto-generated method stub
		User c= userRepository.save(user);
		return userconverter.convertToUserDTO(c);
	}

	@Override
	public List<UserDTO> getAllUserInfo() {
		// TODO Auto-generated method stub
		List<User> user= userRepository.findAll();
		List<UserDTO> dtos= new ArrayList<>();
		for(User c:user)
		{
			dtos.add(userconverter.convertToUserDTO(c));
		}
		
		
		return dtos;
	}

	@Override
	public UserDTO getUserById(int id) {
		// TODO Auto-generated method stub
		User c= userRepository.findById(id).get();
		return userconverter.convertToUserDTO(c);
	}

	@Override
	public String deleteUserById(int id) {
		// TODO Auto-generated method stub
		 userRepository.deleteById(id);
		 return "User deleted.";
	}

	@Override
	public UserDTO updateUser(int id, User user) {
		// TODO Auto-generated method stub
		
		User c1=userRepository.findById(id).get();
		c1.setName(user.getName());
		c1.setAddress(user.getAddress());
		c1.setContact(user.getContact());
		
		
		User u= userRepository.save(c1);
		return userconverter.convertToUserDTO(u);
	}

	
}
