package com.example.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.DTO.PaymentdetailDTO;
import com.example.entities.Paymentdetail;
import com.example.repository.PaymentdetailRepository;
import com.example.utility.PaymentdetailConverter;

@Service
public class PaymentdetailServiceImpl implements PaymentdetailService {

	@Autowired
	private PaymentdetailRepository paymentdetailRepository;
	
	@Autowired
	PaymentdetailConverter paymentdetailconverter;
	
	
	public Paymentdetail savePaymentdetail(Paymentdetail paymentdetail) {
		// TODO Auto-generated method stub
		return paymentdetailRepository.save(paymentdetail);
	}

	
	public List<Paymentdetail> getAllPaymentdetail(){
		
		return paymentdetailRepository.findAll();
		
	}
	
	@Override
	public PaymentdetailDTO createPaymentdetail(Paymentdetail paymentdetail) {
		// TODO Auto-generated method stub
		Paymentdetail p= paymentdetailRepository.save(paymentdetail);
	  return paymentdetailconverter.convertToPaymentdetailDTO(p);
	}

	@Override
	public List<PaymentdetailDTO> getAllPaymentdetailInfo() {
		// TODO Auto-generated method stub
		List<Paymentdetail> paymentdetail= paymentdetailRepository.findAll();
		List<PaymentdetailDTO> dtos=new ArrayList<>();
		for(Paymentdetail p:paymentdetail)
		{
			dtos.add(paymentdetailconverter.convertToPaymentdetailDTO(p));
		}
		
		
		return dtos;
	}

	@Override
	public PaymentdetailDTO getPaymentdetailById(int id) {
		// TODO Auto-generated method stub
		Paymentdetail p1 = paymentdetailRepository.findById(id).get();
		return paymentdetailconverter.convertToPaymentdetailDTO(p1);
	}

	@Override
	public String deletePaymentdetailById(int id) {
		// TODO Auto-generated method stub
		paymentdetailRepository.deleteById(id);
				return "Paymentdetails deleted.";
	}

	@Override
	public PaymentdetailDTO updatePaymentdetail(int id, Paymentdetail paymentdetail) {
		// TODO Auto-generated method stub
		
		Paymentdetail a1 = paymentdetailRepository.findById(id).get();
		a1.setAmount(paymentdetail.getAmount());
		a1.setMethod(paymentdetail.getMethod());
		
		
		
		Paymentdetail p=paymentdetailRepository.save(a1);
		return paymentdetailconverter.convertToPaymentdetailDTO(p);
	}
}
