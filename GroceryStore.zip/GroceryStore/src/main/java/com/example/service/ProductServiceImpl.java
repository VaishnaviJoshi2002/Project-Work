package com.example.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.DTO.ProductDTO;
import com.example.entities.Product;
import com.example.repository.ProductRepository;
import com.example.utility.ProductConverter;



@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	ProductConverter productconverter;
	
	public Product saveProduct(Product product) {
		// TODO Auto-generated method stub
		return productRepository.save(product);
	}

	
	public List<Product> getAllProduct(){
		
		return productRepository.findAll();
		
	}
	
	@Override
	public ProductDTO createProduct(Product product) {
		// TODO Auto-generated method stub
		Product p= productRepository.save(product);
	  return productconverter.convertToProductDTO(p);
	}

	@Override
	public List<ProductDTO> getAllProductInfo() {
		// TODO Auto-generated method stub
		List<Product> product= productRepository.findAll();
		List<ProductDTO> dtos=new ArrayList<>();
		for(Product p:product)
		{
			dtos.add(productconverter.convertToProductDTO(p));
		}
		
		
		return dtos;
	}

	@Override
	public ProductDTO getProductById(int id) {
		// TODO Auto-generated method stub
		Product p1 = productRepository.findById(id).get();
		return productconverter.convertToProductDTO(p1);
	}

	@Override
	public String deleteProductById(int id) {
		// TODO Auto-generated method stub
		productRepository.deleteById(id);
				return "Product deleted.";
	}

	@Override
	public ProductDTO updateProduct(int id, Product product) {
		// TODO Auto-generated method stub
		
		Product a1 = productRepository.findById(id).get();
		a1.setPName(product.getPName());
		a1.setPPrice(product.getPPrice());
		a1.setPDesc(product.getPDesc());
		
		
		
		Product p=productRepository.save(a1);
		return productconverter.convertToProductDTO(p);
	}
}
