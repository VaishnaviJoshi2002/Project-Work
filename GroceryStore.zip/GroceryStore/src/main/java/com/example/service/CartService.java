package com.example.service;

import java.util.List;
import com.example.DTO.CartDTO;
import com.example.entities.Cart;


public interface CartService{


	public Cart saveCart(Cart cart);
	
	public List<Cart> getAllCart();

	public CartDTO createCart(Cart cart);
	public List<CartDTO> getAllCartInfo();
	public CartDTO getCartById(int id);
	public String deleteCartById(int id);
	public CartDTO updateCart(int id, Cart cart);


}
