package com.example.service;

import java.util.List;

import com.example.DTO.AdminDTO;
import com.example.entities.Admin;

public interface AdminService {

	public Admin saveAdmin(Admin admin);
	
	public List<Admin> getAllAdmin();
	
	public AdminDTO createAdmin(Admin admin);
	public List<AdminDTO> getAllAdminInfo();
	public AdminDTO getAdminById(int id);
	public String deleteAdminById(int id);
	public AdminDTO updateAdmin(int id, Admin admin);

}
