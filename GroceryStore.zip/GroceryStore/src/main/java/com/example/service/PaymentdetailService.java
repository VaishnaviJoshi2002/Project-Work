package com.example.service;

import java.util.List;
import com.example.DTO.PaymentdetailDTO;
import com.example.entities.Paymentdetail;

public interface PaymentdetailService {

public Paymentdetail savePaymentdetail(Paymentdetail paymentdetail);
	
	public List<Paymentdetail> getAllPaymentdetail();
	public PaymentdetailDTO createPaymentdetail(Paymentdetail paymentdetail);
	public List<PaymentdetailDTO> getAllPaymentdetailInfo();
	public PaymentdetailDTO getPaymentdetailById(int id);
	public String deletePaymentdetailById(int id);
	public PaymentdetailDTO updatePaymentdetail(int id, Paymentdetail paymentdetail);
}
