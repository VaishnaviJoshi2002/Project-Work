package com.example.service;

import java.util.List;
import com.example.DTO.ProductDTO;
import com.example.entities.Product;


public interface ProductService {

   public Product saveProduct(Product product);
	
	public List<Product> getAllProduct();

	public ProductDTO createProduct(Product product);
	public List<ProductDTO> getAllProductInfo();
	public ProductDTO getProductById(int id);
	public String deleteProductById(int id);
	public ProductDTO updateProduct(int id, Product product);
}
