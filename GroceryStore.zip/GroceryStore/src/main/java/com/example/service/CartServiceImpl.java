package com.example.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.DTO.CartDTO;
import com.example.entities.Cart;
import com.example.repository.CartRepository;
import com.example.utility.CartConverter;


@Service
public class CartServiceImpl  implements CartService{

	@Autowired
	private CartRepository cartRepository;
	
	@Autowired
    CartConverter cartconverter;
	
	
	public Cart saveCart(Cart cart) {
		// TODO Auto-generated method stub
		return cartRepository.save(cart);
	}

	
	public List<Cart> getAllCart(){
		
		return cartRepository.findAll();
		
	}
	
	@Override
	public CartDTO createCart(Cart cart) {
		// TODO Auto-generated method stub
	  Cart c= cartRepository.save(cart);
	  return cartconverter.convertToCartDTO(c);
	}

	@Override
	public List<CartDTO> getAllCartInfo() {
		// TODO Auto-generated method stub
		List<Cart> cart= cartRepository.findAll();
		List<CartDTO> dtos=new ArrayList<>();
		for(Cart c:cart)
		{
			dtos.add(cartconverter.convertToCartDTO(c));
		}
		
		
		return dtos;
	}

	@Override
	public CartDTO getCartById(int id) {
		// TODO Auto-generated method stub
		Cart c1 = cartRepository.findById(id).get();
		return cartconverter.convertToCartDTO(c1);
	}

	@Override
	public String deleteCartById(int id) {
		// TODO Auto-generated method stub
				cartRepository.deleteById(id);
				return "Cart deleted.";
	}

	@Override
	public CartDTO updateCart(int id, Cart cart) {
		// TODO Auto-generated method stub
		
		Cart a1 = cartRepository.findById(id).get();
		a1.setCartId(cart.getCartId());
		a1.setUserId(cart.getUserId());
		
		
		
		Cart c=cartRepository.save(a1);
		return cartconverter.convertToCartDTO(c);
	}
	
}
