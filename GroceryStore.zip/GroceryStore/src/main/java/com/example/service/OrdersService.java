package com.example.service;

import java.util.List;
import com.example.DTO.OrdersDTO;
import com.example.entities.Orders;

public interface OrdersService {


	public Orders saveOrders(Orders orders);
	
	public List<Orders> getAllOrders();
	
	public OrdersDTO createOrders(Orders orders);
	public List<OrdersDTO> getAllOrdersInfo();
	public OrdersDTO getOrdersById(int id);
	public String deleteOrdersById(int id);
	public OrdersDTO updateOrders(int id, Orders orders);

}
