package com.example.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.DTO.AdminDTO;
import com.example.entities.Admin;
import com.example.repository.AdminRepository;
import com.example.utility.AdminConverter;

@Service
public class AdminServiceImpl implements AdminService{


	@Autowired
	private AdminRepository adminRepository;
	
	@Autowired
    AdminConverter adminconverter;
	
	public Admin saveAdmin(Admin admin) {
		// TODO Auto-generated method stub
		return adminRepository.save(admin);
	}

	
	public List<Admin> getAllAdmin(){
		
		return adminRepository.findAll();
		
	}

	@Override
	public AdminDTO createAdmin(Admin admin) {
		// TODO Auto-generated method stub
	  Admin adm= adminRepository.save(admin);
	  return adminconverter.convertToAdminDTO(adm);
	}

	@Override
	public List<AdminDTO> getAllAdminInfo() {
		// TODO Auto-generated method stub
		List<Admin> admin= adminRepository.findAll();
		List<AdminDTO> dtos=new ArrayList<>();
		for(Admin a:admin)
		{
			dtos.add(adminconverter.convertToAdminDTO(a));
		}
		
		
		return dtos;
	}

	@Override
	public AdminDTO getAdminById(int id) {
		// TODO Auto-generated method stub
		Admin a = adminRepository.findById(id).get();
		return adminconverter.convertToAdminDTO(a);
	}

	@Override
	public String deleteAdminById(int id) {
		// TODO Auto-generated method stub
				adminRepository.deleteById(id);
				return "Admin deleted.";
	}

	@Override
	public AdminDTO updateAdmin(int id, Admin admin) {
		// TODO Auto-generated method stub
		
		Admin a1 = adminRepository.findById(id).get();
		a1.setAdminName(admin.getAdminName());
		a1.setAdminUsername(admin.getAdminUsername());
		a1.setAdminPassword(admin.getAdminPassword());
		
		
		Admin adm=adminRepository.save(a1);
		return adminconverter.convertToAdminDTO(adm);
	}
	
}
