package com.example.DTO;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class ProductDTO {

	private int pId;
	
	@NotNull(message = "Product name cannot be null")
	@NotBlank(message = "Product name cannot be blank")
	private String pName;
	
	@NotNull(message = "Price is required")
	@Positive(message = "Price must be positive")
	private double pPrice;
	
	@NotNull(message = "Product desc cannot be null")
	@NotBlank(message = "Product desc cannot be blank")
	private String pDesc;

	
}
