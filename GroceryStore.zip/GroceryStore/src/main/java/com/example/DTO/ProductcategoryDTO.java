package com.example.DTO;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductcategoryDTO {

	private int cId;
	
	@NotNull(message = "Category name cannot be null")
	@NotBlank(message = "Category name cannot be blank")
	private String cName;
	
	
}
