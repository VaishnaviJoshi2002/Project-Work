package com.example.DTO;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentdetailDTO {

	private int pId;
	
	@NotNull(message = "Amount is required")
	@Positive(message = "Amount must be positive")
	private long amount;
	
	private String method;

	
}
