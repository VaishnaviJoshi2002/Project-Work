package com.example.DTO;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserDTO {

	private int userId;
	
	@NotNull(message = " Customer name cannot be null")
	@NotBlank(message =  "Customer name cannot be blank")
	private String name;
	
	@NotNull(message = "Address cannot be null")
	@NotBlank(message = "Address cannot be blank")
	private String address;
	
	@NotNull(message = "Contact number is required")
	private long contact;

	
}
