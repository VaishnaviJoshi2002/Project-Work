package com.example.DTO;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CartDTO {

	private int cardId;
	
	@NotNull(message = "User ID cannot be null")
	private int userId;

	
}
