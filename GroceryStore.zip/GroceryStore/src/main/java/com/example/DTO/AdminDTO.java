package com.example.DTO;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdminDTO {
	
	private long adminId;
	
	@NotBlank
	@Size(min = 2, max = 20, message= "Admin Name should contains only 2 to 20 characters")
	private String adminName;
	@NotBlank
	@Size(min = 2, max = 20, message= "Admin Username should contains only 2 to 20 characters")
	private String adminUsername;
	@NotBlank
	@Size(min = 2, max = 20, message= "Admin Password should contains only 2 to 20 characters")
	private String adminPassword;
	
	 
}
