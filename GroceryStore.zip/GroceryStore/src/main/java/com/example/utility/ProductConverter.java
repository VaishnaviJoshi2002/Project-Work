package com.example.utility;

import org.springframework.beans.BeanUtils;


import com.example.DTO.ProductDTO;
import com.example.entities.Product;

public class ProductConverter {
	
	public Product convertToProductEntity(ProductDTO productDTO)
	{
		Product product=new Product();
		if(productDTO!=null)
		{
			BeanUtils.copyProperties(productDTO, product);
		}
		return product;
	}
	
	//Convert Entity to DTO
	public ProductDTO convertToProductDTO(Product product)
	{
		ProductDTO productDTO=new ProductDTO();
		if(product!=null)
		{
			BeanUtils.copyProperties(product, productDTO);
		}
		return productDTO;
	}

}
