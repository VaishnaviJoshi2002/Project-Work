package com.example.utility;

import org.springframework.beans.BeanUtils;


import com.example.DTO.UserDTO;
import com.example.entities.User;

public class UserConverter {

	public User convertToUserEntity(UserDTO userDTO)
	{
		User user=new User();
		if(userDTO!=null)
		{
			BeanUtils.copyProperties(userDTO, user);
		}
		return user;
	}
	
	//Convert Entity to DTO
	public UserDTO convertToUserDTO(User user)
	{
		UserDTO userDTO=new UserDTO();
		if(user!=null)
		{
			BeanUtils.copyProperties(user, userDTO);
		}
		return userDTO;
	}
}
