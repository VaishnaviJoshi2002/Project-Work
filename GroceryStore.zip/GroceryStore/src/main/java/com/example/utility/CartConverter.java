package com.example.utility;

import org.springframework.beans.BeanUtils;


import com.example.DTO.CartDTO;
import com.example.entities.Cart;

public class CartConverter {

	public Cart convertToCartEntity(CartDTO CartDTO)
	{
		Cart cart=new Cart();
		if(CartDTO!=null)
		{
			BeanUtils.copyProperties(CartDTO, cart);
		}
		return cart;
	}
	
	//Convert Entity to DTO
	public CartDTO convertToCartDTO(Cart cart)
	{
		CartDTO cartDTO=new CartDTO();
		if(cart!=null)
		{
			BeanUtils.copyProperties(cart, cartDTO);
		}
		return cartDTO;
	}

}
