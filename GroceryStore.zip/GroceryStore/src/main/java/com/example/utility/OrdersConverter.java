package com.example.utility;

import org.springframework.beans.BeanUtils;


import com.example.DTO.OrdersDTO;
import com.example.entities.Orders;

public class OrdersConverter {

	public Orders convertToOrdersEntity(OrdersDTO ordersDTO)
	{
		Orders orders=new Orders();
		if(ordersDTO!=null)
		{
			BeanUtils.copyProperties(ordersDTO, orders);
		}
		return orders;
	}
	
	//Convert Entity to DTO
	public OrdersDTO convertToOrdersDTO(Orders orders)
	{
		OrdersDTO ordersDTO=new OrdersDTO();
		if(orders!=null)
		{
			BeanUtils.copyProperties(orders, ordersDTO);
		}
		return ordersDTO;
	}

}
