package com.example.utility;

import org.springframework.beans.BeanUtils;


import com.example.DTO.ProductcategoryDTO;
import com.example.entities.Productcategory;

public class ProductcategoryConverter {

	public Productcategory convertToProductcategoryEntity(ProductcategoryDTO  productcategoryDTO)
	{
		Productcategory productcategory=new Productcategory();
		if(productcategoryDTO!=null)
		{
			BeanUtils.copyProperties(productcategoryDTO, productcategory);
		}
		return productcategory;
	}
	
	//Convert Entity to DTO
	public ProductcategoryDTO convertToProductcategoryDTO(Productcategory productcategory)
	{
		ProductcategoryDTO productcategoryDTO=new ProductcategoryDTO();
		if(productcategory!=null)
		{
			BeanUtils.copyProperties(productcategory, productcategoryDTO);
		}
		return productcategoryDTO;
	}

}
