package com.example.utility;

import org.springframework.beans.BeanUtils;


import com.example.DTO.PaymentdetailDTO;
import com.example.entities.Paymentdetail;

public class PaymentdetailConverter {

	public Paymentdetail convertToPaymentdetailEntity(PaymentdetailDTO paymentdetailDTO)
	{
		Paymentdetail paymentdetail=new Paymentdetail();
		if(paymentdetailDTO!=null)
		{
			BeanUtils.copyProperties(paymentdetailDTO, paymentdetail);
		}
		return paymentdetail;
	}
	
	//Convert Entity to DTO
	public PaymentdetailDTO convertToPaymentdetailDTO(Paymentdetail paymentdetail)
	{
		PaymentdetailDTO paymentdetailDTO=new PaymentdetailDTO();
		if(paymentdetail!=null)
		{
			BeanUtils.copyProperties(paymentdetail, paymentdetailDTO);
		}
		return paymentdetailDTO;
	}

}
