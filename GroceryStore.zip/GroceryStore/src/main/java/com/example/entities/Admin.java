package com.example.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

@Entity
public class Admin {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="adminId",length=20)
	private int adminId;
	
	@Column(name="adminName",length=20)
	private String adminName;
	
	@Column(name="adminUsername",length=20)
	private String adminUsername;
	
	@Column(name="adminPassword",length=20)
	private String adminPassword;
	
}
