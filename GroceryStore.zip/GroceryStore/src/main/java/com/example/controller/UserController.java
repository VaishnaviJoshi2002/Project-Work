package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.DTO.UserDTO;
import com.example.entities.User;
import com.example.service.UserService;
import com.example.utility.UserConverter;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/User")
public class UserController {

		@Autowired
		private UserService userService;
		
		@Autowired
		UserConverter userconverter;
		
		@PostMapping("/add")
		public String add(@RequestBody User user) {
			userService.saveUser(user);
			return "New User Added";
			
		}
		@GetMapping("/getAll")
		public List<User> getAllUser(){
			
			return userService.getAllUser();
			
		}
		@PostMapping("/createUser")
	    ResponseEntity<UserDTO> createUser(@Valid @RequestBody UserDTO userDto) {
			final User user=userconverter.convertToUserEntity(userDto);
			return new ResponseEntity<UserDTO>(userService.createUser(user),HttpStatus.CREATED);
			
		}
		@GetMapping("/getAllUser")
		public List<UserDTO> getAllUserInfo(){
			return userService.getAllUserInfo();
		}
		
		@GetMapping("/getUserById/{uid}")
		public UserDTO geUserById(@PathVariable("uid") int id) {
			return userService.getUserById(id);
		}
		
		@DeleteMapping("/deleteUserById/{uid}")
		public String deleteUserById(@PathVariable("uid") int id)
		{
			userService.deleteUserById(id);
			return "User deleted.";
			
		}
		
		@PutMapping("/updateUser/{uid}")
		public UserDTO updateUser(@PathVariable("uid") int id, @RequestBody User user) {
			return userService.updateUser(id, user);
			
		}
	}


