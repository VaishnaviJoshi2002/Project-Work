package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.DTO.ProductDTO;
import com.example.entities.Product;
import com.example.service.ProductService;
import com.example.utility.ProductConverter;

import jakarta.validation.Valid;



@RestController
@RequestMapping("/product")
public class ProductController {

		@Autowired
		private ProductService productService;
		
		@Autowired
		ProductConverter productconverter;
		
		@PostMapping("/add")
		public String add(@RequestBody Product product) {
			productService.saveProduct(product);
			return "New Product Added";
			
		}
		@GetMapping("/getAll")
		public List<Product> getAllProduct(){
			
			return productService.getAllProduct();
			
		}
		
		@PostMapping("/createProduct")
		 ResponseEntity<ProductDTO> createProduct(@Valid @RequestBody ProductDTO productDto) {
			final Product product=productconverter.convertToProductEntity(productDto);
			return new ResponseEntity<ProductDTO>(productService.createProduct(product),HttpStatus.CREATED);
		}
		

		@GetMapping("/getAllProduct")
		public List<ProductDTO> getAllProductInfo(){
			return productService.getAllProductInfo();
		}
		
		@GetMapping("/getProductById/{pid}")
		public ProductDTO getProductById(@PathVariable("pid") int id) {
			return productService.getProductById(id);
		}
		
		
		@DeleteMapping("/deleteProductById/{pid}")
		public String deleteProductById(@PathVariable("pid") int id)
		{
			productService.deleteProductById(id);
			return "Product deleted.";
			
		}
		
		@PutMapping("/updateProduct/{pid}")
		public ProductDTO updateProduct(@PathVariable("pid") int id, @RequestBody Product product) {
			return productService.updateProduct(id, product);
			
		}
		
		
	}