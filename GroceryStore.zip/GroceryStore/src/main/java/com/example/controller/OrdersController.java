package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.DTO.OrdersDTO;
import com.example.entities.Orders;
import com.example.service.OrdersService;
import com.example.utility.OrdersConverter;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/orders")
public class OrdersController {

		@Autowired
		private OrdersService ordersService;
		
		@Autowired
		OrdersConverter ordersconverter;
		
		@PostMapping("/add")
		public String add(@RequestBody Orders orders) {
			ordersService.saveOrders(orders);
			return "New Order Added";
			
		}
		@GetMapping("/getAll")
		public List<Orders> getAllOrders(){
			
			return ordersService.getAllOrders();
			
		}
		
		@PostMapping("/createOrders")
		 ResponseEntity<OrdersDTO> createOrders(@Valid @RequestBody OrdersDTO ordersDto) {
			final Orders orders=ordersconverter.convertToOrdersEntity(ordersDto);
			return new ResponseEntity<OrdersDTO>(ordersService.createOrders(orders),HttpStatus.CREATED);
		}
		

		@GetMapping("/getAllOrders")
		public List<OrdersDTO> getAllOrdersInfo(){
			return ordersService.getAllOrdersInfo();
		}
		
		@GetMapping("/getOrdersById/{oid}")
		public OrdersDTO getOrdersById(@PathVariable("oid") int id) {
			return ordersService.getOrdersById(id);
		}
		
		
		@DeleteMapping("/deleteOrdersById/{oid}")
		public String deleteOrdersById(@PathVariable("oid") int id)
		{
			ordersService.deleteOrdersById(id);
			return "Orders deleted.";
			
		}
		
		@PutMapping("/updateOrders/{cid}")
		public OrdersDTO updateOrders(@PathVariable("oid") int id, @RequestBody Orders orders) {
			return ordersService.updateOrders(id, orders);
			
		}
		
		
	}