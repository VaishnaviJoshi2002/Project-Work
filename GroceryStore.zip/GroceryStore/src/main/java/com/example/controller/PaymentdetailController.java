package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.DTO.PaymentdetailDTO;
import com.example.entities.Paymentdetail;
import com.example.service.PaymentdetailService;
import com.example.utility.PaymentdetailConverter;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/payment")
public class PaymentdetailController {

		@Autowired
		private PaymentdetailService paymentdetailService;
		
		@Autowired
		PaymentdetailConverter paymentdetailconverter;
		
		
		@PostMapping("/add")
		public String add(@RequestBody Paymentdetail paymentdetail) {
			paymentdetailService.savePaymentdetail(paymentdetail);
			return "New Payment Added";
			
		}
		@GetMapping("/getAll")
		public List<Paymentdetail> getAllPaymentdetail(){
			
			return paymentdetailService.getAllPaymentdetail();
			
		}
		
		@PostMapping("/createPaymentdetail")
		 ResponseEntity<PaymentdetailDTO> createPaymentdetail(@Valid @RequestBody PaymentdetailDTO paymentdetailDto) {
			final Paymentdetail paymentdetail=paymentdetailconverter.convertToPaymentdetailEntity(paymentdetailDto);
			return new ResponseEntity<PaymentdetailDTO>(paymentdetailService.createPaymentdetail(paymentdetail),HttpStatus.CREATED);
		}
		

		@GetMapping("/getAllPaymentdetail")
		public List<PaymentdetailDTO> getAllPaymentdetailInfo(){
			return paymentdetailService.getAllPaymentdetailInfo();
		}
		
		@GetMapping("/getPaymentdetailById/{pid}")
		public PaymentdetailDTO getPaymentdetailById(@PathVariable("pid") int id) {
			return paymentdetailService.getPaymentdetailById(id);
		}
		
		
		@DeleteMapping("/deletePaymentdetailById/{pid}")
		public String deletePaymentdetailById(@PathVariable("pid") int id)
		{
			paymentdetailService.deletePaymentdetailById(id);
			return "Paymentdetails deleted.";
			
		}
		
		@PutMapping("/updatePaymentdetail/{pid}")
		public PaymentdetailDTO updatePaymentdetail(@PathVariable("pid") int id, @RequestBody Paymentdetail paymentdetail) {
			return paymentdetailService.updatePaymentdetail(id, paymentdetail);
			
		}
		
		
	}