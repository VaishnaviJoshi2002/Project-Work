package com.example.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.DTO.CartDTO;
import com.example.entities.Cart;
import com.example.service.CartService;
import com.example.utility.CartConverter;

import jakarta.validation.Valid;



@RestController
@RequestMapping("/Cart")
public class CartController {

		@Autowired
		private CartService cartService;
		
		@Autowired
		CartConverter cartconverter;
		
		@PostMapping("/add")
		public String add(@RequestBody Cart cart) {
			cartService.saveCart(cart);
			return "New Cart Added";
			
		}
		@GetMapping("/getAll")
		public List<Cart> getAllCart(){
			
			return cartService.getAllCart();
			
		}
		@PostMapping("/createCart")
		 ResponseEntity<CartDTO> createCart(@Valid @RequestBody CartDTO cartDto) {
			final Cart cart=cartconverter.convertToCartEntity(cartDto);
			return new ResponseEntity<CartDTO>(cartService.createCart(cart),HttpStatus.CREATED);
		}
		

		@GetMapping("/getAllCart")
		public List<CartDTO> getAllCartInfo(){
			return cartService.getAllCartInfo();
		}
		
		@GetMapping("/getCartById/{cid}")
		public CartDTO getCartById(@PathVariable("cid") int id) {
			return cartService.getCartById(id);
		}
		
		
		@DeleteMapping("/deleteCartById/{cid}")
		public String deleteCartById(@PathVariable("cid") int id)
		{
			cartService.deleteCartById(id);
			return "Cart deleted.";
			
		}
		
		@PutMapping("/updateCart/{cid}")
		public CartDTO updateCart(@PathVariable("cid") int id, @RequestBody Cart cart) {
			return cartService.updateCart(id, cart);
			
		}
		
		
	}