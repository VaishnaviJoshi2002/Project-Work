package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.DTO.ProductcategoryDTO;
import com.example.entities.Productcategory;
import com.example.service.ProductcategoryService;
import com.example.utility.ProductcategoryConverter;

import jakarta.validation.Valid;


@RestController
@RequestMapping("/productcategory")
public class ProductcategoryController {

		@Autowired
		private ProductcategoryService productcategoryService;
		
		@Autowired
		ProductcategoryConverter productcategoryconverter;
		
		@PostMapping("/add")
		public String add(@RequestBody Productcategory productcategory) {
			productcategoryService.saveProductcategory(productcategory);
			return "New Product category Added";
			
		}
		@GetMapping("/getAll")
		public List<Productcategory> getAllProductcategory(){
			
			return productcategoryService.getAllProductcategory();
			
		}
		
		@PostMapping("/createProductcategory")
		 ResponseEntity<ProductcategoryDTO> createProductcategory(@Valid @RequestBody ProductcategoryDTO productcategoryDto) {
			final Productcategory productcategory=productcategoryconverter.convertToProductcategoryEntity(productcategoryDto);
			return new ResponseEntity<ProductcategoryDTO>(productcategoryService.createProductcategory(productcategory),HttpStatus.CREATED);
		}
		

		@GetMapping("/getAllProductcategory")
		public List<ProductcategoryDTO> getAllProductcategoryInfo(){
			return productcategoryService.getAllProductcategoryInfo();
		}
		
		@GetMapping("/getProductcategoryById/{pid}")
		public ProductcategoryDTO getProductcategoryById(@PathVariable("pid") int id) {
			return productcategoryService.getProductcategoryById(id);
		}
		
		
		@DeleteMapping("/deleteProductcategoryById/{pid}")
		public String deleteProductcategoryById(@PathVariable("pid") int id)
		{
			productcategoryService.deleteProductcategoryById(id);
			return "Productcategory deleted.";
			
		}
		
		@PutMapping("/updateProductcategory/{pid}")
		public ProductcategoryDTO updateProductcategory(@PathVariable("pid") int id, @RequestBody Productcategory productcategory) {
			return productcategoryService.updateProductcategory(id, productcategory);
			
		}
		
		
		
	}